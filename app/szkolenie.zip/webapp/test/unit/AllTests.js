sap.ui.define([
	"szkolenie/szkolenie/test/unit/controller/View1.controller"
], function () {
	"use strict";
});